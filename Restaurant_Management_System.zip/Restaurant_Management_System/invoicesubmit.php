<?php
session_start();
$id = $_SESSION['id'];
$id= (int)$id;
echo gettype ($id );
?>
 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
//echo "<body style='background-color:pink'>";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$k="Table".$id;
$l='A'.$k;    
echo $k;
echo $l;
$sql = "INSERT INTO $l 
SELECT *
FROM $k";
if (mysqli_query($conn, $sql)) {
   // echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
$sql1="Truncate table $k";
if (mysqli_query($conn, $sql1)) {
   // echo "New record created successfully";
} else {
    echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
}
  ?>
      <script>
	  alert("THANK YOU !! YOU CAN PAY YOUR BILL AT THE RECEPTION.");
		
	  </script>
      <?php
redirect ("/Fcomm/index1.php");

function redirect($url, $permanent = false) {
	if($permanent) {
		header('HTTP/1.1 301 Moved Permanently');
	}
	header('Location: '.$url);
	exit();
}
$conn->close();

?>
 

