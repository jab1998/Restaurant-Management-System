

 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
echo "<body style='background-color:pink'>";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//$Album = mysqli_real_escape_string($conn, $_REQUEST['Album']);
$sql = "select * from Menu natural join Item";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
	echo '<table border="10" bgcolor="#00FF00" align="center">'; 
echo '<caption><h1 style="color: #FFF; background: #000">MENU</h1></caption>';
echo '<form action="Orders.php" method="post">';

echo '<tr><td>S.no</td><td align="center">Item Name</td><td>Price</td></tr>';
    while($row = $result->fetch_assoc()) {
	$a=$row['ItemId'];
    echo "<tr><td align='center'>"; 
	echo $row['ItemId'];
	echo "</td><td align='center'>";    
	echo $row['Item_Name'];
	echo "</td><td align='center'>";    
	echo $row['Price']." "."/-";
	echo "</td><td align='center'>";    
	echo '<input type="checkbox" name="check_list[]" value="'.$a.'">';
	echo "</TD></tr>";  
    }
echo '<tr><td align="center" colspan="4"><input type="submit" value ="Place Order" class="button" /></td></tr>';
echo '</form>';
} else {
    echo "0 results";
}
$conn->close();
?> 
<?php
if(!empty($_POST['check_list'])) {
    foreach($_POST['check_list'] as $check) {
            echo $check; //echoes the value set in the HTML form for each checked checkbox.
                         //so, if I were to check 1, 3, and 5 it would echo value 1, value 3, value 5.
                         //in your case, it would echo whatever $row['Report ID'] is equivalent to.
    }
}
?>
