<?php
session_start();
require("config.php"); 
?>				
<?php
$k=(string)$uid;
$query = mysql_query("select * FROM Orders natural join Menu Natural Join Item ORDER BY OrderId DESC");
if(mysql_num_rows($query)>0)
{
	
?>
<table border="1" bordercolor="#000000" width="805" height="62" align="center" cellpadding="1" class="table">

<tr align="center"><td width="115">OrderId</td><td width="122">TableId</td><td width="117">ItemId</td><td width="117">ItemName</td></tr>
<tr>&nbsp;</tr>
<?php
while($r = mysql_fetch_array($query))
{
	$oid = $r['OrderId'];
	$tid = $r['TableId'];
	$iid = $r['ItemId'];
	$in = $r['Item_Name'];
	
	?>
    <tr align="center">
    <td width="115"><?php echo $oid; ?></td>
    <td><?php echo $tid; ?></td>
    <td><?php echo $iid; ?></td>
    <td><?php echo $in; ?></td>
    <td>
    <form name="f">
    <input type="button" name="cancel" value="Cancel" onclick="clk()" />
    </form>
    </td></tr>
    <?php
}?>
</table>
<?php
}else
{
	?>
    <script>
	alert("You dont have any booking history");
	window.location = "Home.php?id=<?php echo $uid; ?>";
	</script>
<!--    <h2 style="font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif">You Dont Have any Booking History</h2>
-->    <?php
}
?>
<a href="Home.php?id=<?php echo $uid;?>">Back to Home</a>
$
<script>
function clk()
{
	var cancel = confirm("Are You Sure You Want to Cancel the Ticket");
	if(cancel == true)
	{
		window.location = "cancel.php?id=<?php echo $uid; ?>&seat_id=<?php echo $seat_no_booked; ?>&bus_id=<?php echo $bus_id; ?>&did=<?php echo $id;?>";
	}
	
}

</script>
				<br />
			</div>
			
		</header>
<!-- / header -->
	</div>

</div>

<script type="text/javascript"> Cufon.now(); </script>
<?php

$uid=$_SESSION['id'];

$sql = mysql_query("select * from register where id = '$uid'");
$r = mysql_fetch_array($sql);
$password = sha1($r['password']);

if(isset($_POST['pas'])){
	$oldp = sha1($_POST['oldp']);
	$newp = sha1($_POST['newp']);
	$conp = sha1($_POST['conp']);
	
 	if($oldp=='' || $oldp=='' || $newp==''){
		echo "<table class=table cellpadding=0 cellspacing=0 align=center bgcolor=#FFFF66 style=font-family:verdana;>
		<tr><td><font color=#FF0000 size=2>&nbsp;Please Enter The Password in All Fields &nbsp;</font></td></tr></table>";
	}
	else if($oldp!=$password){
			echo "<table class=table cellpadding=0 cellspacing=0 align=center bgcolor=#FFFF66 style=font-family:verdana;>
		<tr><td><font color=#FF0000 size=2>&nbsp;The Old Password is incorrect &nbsp;</font></td></tr></table>";
			}
	
	else if($newp != $conp){
		echo "<table class=table cellpadding=0 cellspacing=0 align=center bgcolor=#FFFF66 style=font-family:verdana;>
		<tr><td><font color=#FF0000 size=2>&nbsp; New Password and Confirm Password are not match &nbsp;</font></td></tr></table>";
		}
		
else{
	$sql = mysql_query("update register set password='$newp' where id='$uid' AND password='$oldp'");
	header('location:Home.php?id=$uid');
	?>
    <script>
	alert('Password Successfully changed');
	</script>
    <?php
	
	}

}

}
else
{
	header("Location:Home.php?id=$uid");
}
?>
</body>
</html>
