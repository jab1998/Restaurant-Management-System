
<?php
require("config.php");
session_start();
?>
<link rel="stylesheet" href="style.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css"> 
	<link rel="stylesheet" type="text/css" href="assets/css/page-style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/hexagons.min.css"> 
	<script src="assets/js/jquery-2.1.0.min.js"></script>
	<script src="assets/js/hexagons.min.js"></script>
<br><br>
<div id="container">
<div>
	 <a href="index.php"> <img src="logo.png"  align="left" style="width:200px;height:100px;"></a>
		<center><a href="#"><span class="hb hb-sm spin"><i class="fa fa-facebook"></i></span></a>
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-twitter"></i></span></a> 
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-google-plus"></i></span></a>
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-youtube"></i></span></a>
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-linkedin-square"></i></span></a></center>
	</div>
<div id="header">
<a href="/Fcomm/index.php">	<div class="button gray"><div class="shine"></div>HOME</div></a>
<a href="/Fcomm/about.php"><div class="button blue"><div class="shine"></div>ABOUT</div></a>
<a href="/Fcomm/contact.php"><div class="button purple"><div class="shine"></div>CONTACT</div></a>
<a href="/Fcomm/MLogin.php"><div class="button orange"><div class="shine"></div>Management Login</div></a>​   
	</div>
    
    <div id="primary">
	<img src="image1.jpg" style="width:240px;height:490px;">

    </div>
    
    <div id="content" style="overflow-x:scroll ; overflow-y: scroll; padding-bottom:10px;">
        <div><br><br><br><br><br>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="LoginForm">
<div>TableId : &nbsp;&nbsp;&nbsp;&nbsp;<input class="input" type="integer" name="TableId" required placeholder="TableId" autocomplete="off"/></div><br><br>
<div>Password : <input class="input" type='password' name="pass" required placeholder="Password" autocomplete="off"/></div>
<input class="button" type="submit" onclick="validate()" name="login" value="Login" />
</form></div>
    </div>
    
    
    
    <div id="footer">
        <p>&copy; GASS Restaurants<p>
    </div>
</div>
<?php
if(isset($_POST['login'])){
$Id = $_POST['TableId'];	
$pass = $_POST['pass'];
echo $Id,$pass; 

  $sql = mysql_query("select * from `Tables` where TableId='$Id' AND password='$pass'");

  if(mysql_num_rows($sql)==0)
  {
	  ?>
      <script>
	  alert("You seem to register first");
	  window.location="register.php";
	  </script>
      <?php
  }
  else
  {
	  ?>
      <script>
	  alert("Welcome  !!!!");
	  </script>
      <?php
	  $sql1 = mysql_query("select * from `Tables` where TableId='$Id' AND password='$pass'");
	  $r = mysql_fetch_array($sql1);
	  $id = $r['TableId'];
	  echo $_SESSION['id'] = $id;
	  echo $_SESSION['orders'] = 0;
	  header("Location:index1.php");
  }
}

?>
