 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$var=$_POST['Item_Name'];
$var1=$_POST['Price'];

$sql =	"UPDATE Item 
	 SET Price='$var1'
	 WHERE Item_Name='$var'";

if(mysqli_query($conn, $sql)){
    header("location:update.html");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

mysqli_close($conn);
?>
